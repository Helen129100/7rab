package com.example.pr7kukakova_zotochkina;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;

public class sign_up extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
    }
    public void registerClicked(View view) {

        Intent intent = new Intent(this, ContactsContract.Profile.class);
        startActivity(intent);
    }
}
